"""
If you wish to have your changes to this file ignored, type the following
command into your terminal:
git update-index --assume-unchanged [path to this file]
"""
import os
import sys
import time

class Network:
    BMC_IPs = []
    DSM_IPs = ["127.0.0.1"]
    DSM_PORT_QUERY = 2203
    DSM_PORT_STATUS = 3110

class Tools:
    # Python Client to use throughout Shenzi, must be an absolute path, if it is an empty string it will default to system client
    CLIENT_PATH = ""

class StrFmt:
    @staticmethod
    def Notice(*args):
        """
        Takes any number of str type args and returns a formated string
        """
        return "["+time.strftime('%Y/%m/%d_%H:%M:%S')+"|"+"|".join(args)+"]"

    @staticmethod
    def ProtoStatus(status):
        """
        Takes a kinetic proto status object and returns a formated string
        """
        return str(status).strip().replace("\n", ".")

class Default:
    INTERFACE = None
