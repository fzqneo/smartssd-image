from .Puts import Puts
from .Gets import Gets
from .Deletes import Deletes