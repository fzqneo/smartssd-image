"""
Kinetic Batches are unique because they are composed with multiple Kinetic
PDUs (start_batch, batched commands, and end_batch) but are processed as
a single command. A user should only ever get a response for a start
batch, end batch, or abort batch message, the other commands within the
batch will never get a response from the drive. For the Kinetic Python
Client, this results in some unique handling of batch commands for
queue_depth and wait_q.
"""
import sys
from argparse import ArgumentParser
from kv_client import Client, kinetic_pb2

StatusCodes = kinetic_pb2.Command.Status.StatusCode
MsgTypes = kinetic_pb2.Command.MessageType

def callback(msg, cmd, value):
    """
    prints out basic information about the response
    """
    print "\t\treceived batchID: "+str(cmd.header.batchID)+\
            ", msgType: "+str(MsgTypes.Name(cmd.header.messageType))+\
            ", statusCode: "+str(StatusCodes.Name(cmd.status.code))

def main():
    parser = ArgumentParser()
    parser.add_argument("-i", "--hostname", required=True, help="The ip address or hostname of the drive to test on")
    args = parser.parse_args()

    print "Create and connect client"
    client = Client(args.hostname)
    client.queue_depth = 1
    client.connect()
    if not client.is_connected:
        print "\tFailed to connect"
        return 1

    print "Issue a batch command"
    # We're going to issue a batch on a client with queue_depth 1 so the
    # user can see that a batch counts as a single command, even though
    # there are 3 puts and 2 deletes outstanding.
    client.callback_delegate = callback

    # This creates and sends a start_batch command and returns a batch
    # object for you to work on. The start batch response will not go
    # through a standard callback delegate. That is configurable
    # and can be read about in the method description.
    batch = client.create_batch_operation()
    for i in range(3):
        batch.put("k"+str(i), "value", synchronization=1)
    for i in range(2):
        batch.delete("k"+str(i), force=True, synchronization=1)
    batch.commit()
    client.wait_q(0)

    print "Issue multiple batch commands"
    # Here is a simple example of sending multiple batches at once. Puts
    # and deletes are the only commands that can be batched
    client.queue_depth = 5
    for i in range(5):
        batch = client.create_batch_operation()
        batch.put("kb"+str(i), "value", synchronization=1)
        batch.delete("kb"+str(i), force=True, synchronization=1)
        batch.commit()
    client.wait_q(0)

    print "Issue an abort batch"
    # Instead of commiting a batch, you can abort it. This tells the drive
    # that you no longer care about the batch and to throw away everything
    # associated with it.
    batch = client.create_batch_operation()
    batch.put("kb"+str(i), "value", synchronization=1)
    batch.abort()
    client.wait_q(0)

    client.close()
    return 0

if __name__=='__main__':
    sys.exit(main())