"""
Kinetic Python Client callbacks allow the user to handle responses either
from the drive or the client detecting a failure (such as socket timeout).
There are many different ways to write your own callback code but here
we've demonstrated some of the more useful examples.
"""
import sys
import time
import random
from argparse import ArgumentParser
from kv_client import Client, kinetic_pb2

StatusCodes = kinetic_pb2.Command.Status.StatusCode
MsgTypes = kinetic_pb2.Command.MessageType

def basic_callback(msg, cmd, value):
    """
    You can handle each callback without passing any information or data
    in from the original call.
    """
    print "\t\tBC: received ackSeq: "+str(cmd.header.ackSequence)+\
                ", msgType: "+str(MsgTypes.Name(cmd.header.messageType))+\
                ", statusCode: "+str(StatusCodes.Name(cmd.status.code))

def data_callback(t0, key, success, failure):
    """
    You can pass in any mutable object (such as a dictionary or list) to
    store/share information between threads or you can pass in information
    for each command issued (such as a start time) for special handling
    in the callback.
    """
    def wrapper(msg, cmd, value):
        t1 = time.time()
        print "\t\tDC: received ackSeq: "+str(cmd.header.ackSequence)+\
                    ", msgType: "+str(MsgTypes.Name(cmd.header.messageType))+\
                    ", statusCode: "+str(StatusCodes.Name(cmd.status.code))+\
                    ", latency: "+str(t1-t0)
        if cmd.status.code != kinetic_pb2.Command.Status.SUCCESS:
            success.append(key)
        else:
            failure.append(key)
    return wrapper

def main():
    parser = ArgumentParser()
    parser.add_argument("-i", "--hostname", required=True, help="The ip address or hostname of the drive to test on")
    args = parser.parse_args()

    print "Create and connect client"
    client = Client(args.hostname)
    client.queue_depth = 5
    client.connect()
    if not client.is_connected:
        print "\tFailed to connect"
        return 1

    # Create a list of commands to randomly cycle through
    commands = ['put("k", "v", force=True, synchronization=1)',
                'get_log(types=[2])',
                'delete("k", synchronization=1)',
                'noop()']

    print "Issue commands without specifying a delegate"
    # The user will not see any information displayed for these commands
    # because no delegate was set
    for _ in range(10):
        command = random.choice(commands)
        exec('client.'+command)
        print "\tIssued "+command.split('(')[0]+"; seq: "+str(client.last_issued_seq)
    client.wait_q(0)
    print "\tAll commands have returned"

    print "Issue commands with basic callback"
    # The user will see print out responses preficed with BC for basic
    # callback
    client.callback_delegate = basic_callback
    for _ in range(10):
        command = random.choice(commands)
        exec('client.'+command)
        print "\tIssued "+command.split('(')[0]+"; seq: "+str(client.last_issued_seq)
    client.wait_q(0)
    print "\tAll commands have returned"

    print "Issue commands after setting delegate to None"
    # The user will not see any information displayed for these commands
    # because the delegate was set to None for these commands
    client.callback_delegate = None
    for _ in range(10):
        command = random.choice(commands)
        exec('client.'+command)
        print "\tIssued "+command.split('(')[0]+"; seq: "+str(client.last_issued_seq)
    client.wait_q(0)
    print "\tAll commands have returned"

    print "Issue commands with data callback"
    # The user will see print out responses preficed with DC for data
    # callback, and the user will have information on the responses
    # stored in local lists
    success = []
    failure = []
    for i in range(10):
        key = "k"+str(i)
        client.callback_delegate = data_callback(time.time(), key, success, failure)
        if (i%3) == 0:
            client.put(key, "value", synchronization=1, version="fake") # make sure some of the keys fail
        else:
            client.put(key, "value", synchronization=1)
        print "\tIssued put; seq: "+str(client.last_issued_seq)
    client.wait_q(0)
    print "\tAll commands have returned"
    print "\tSuccess: "+str(success)
    print "\tFailure: "+str(failure)

    client.close()
    return 0

if __name__=='__main__':
    sys.exit(main())