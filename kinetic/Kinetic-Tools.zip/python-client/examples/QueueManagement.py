"""
Kinetic Python Client has a queue depth that controls how many commands
can be outstanding at any given time. You can set the queue depth to
some value x and once you have x commands outstanding, the client will
block on any command call. Wait q allows the user to wait until a
certain number of commands are outstanding before continuing. Below, we
have demonstrated some basic examples of this.
"""
import sys
import time
import random
from argparse import ArgumentParser
from kv_client import Client, kinetic_pb2

def callback(msg, cmd, value):
    print "\t\treceived ackSeq: "+str(cmd.header.ackSequence)

def main():
    parser = ArgumentParser()
    parser.add_argument("-i", "--hostname", required=True, help="The ip address or hostname of the drive to test on")
    args = parser.parse_args()

    print "Create and connect client"
    client = Client(args.hostname)
    client.connect()
    if not client.is_connected:
        print "\tFailed to connect"
        return 1
    client.callback_delegate = callback

    # I'll set the queue depth to 1. This means that the client will block
    # on sending any new commands to the drive until the last issued
    # command gets a response.
    print "Queuedepth = 1"
    client.queue_depth = 1
    for i in range(10):
        client.put(str(i), "demoQueueMgmt", synchronization=1, force=True)
        print "\tIssued seq: "+str(client.last_issued_seq)

    # wait for all responses to return (0 outstanding)
    client.wait_q(0)

    # Lets look at the same workload with a queue depth of 5 for
    # comparison
    print "Queuedepth = 5"
    client.queue_depth = 5
    for i in range(10):
        client.put(str(i), "demoQueueMgmt", synchronization=1, force=True)
        print "\tIssued seq: "+str(client.last_issued_seq)

    # Calling wait_q with a value >= queue_depth is a do-nothing call.
    # There will never be more than queue_depth outstanding.
    client.wait_q(5)

    # Best practice is to wait for all responses before closing, although
    # this may not always be an option.
    client.wait_q(0)
    client.close()
    return 0

if __name__=='__main__':
    sys.exit(main())