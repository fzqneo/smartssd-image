"""
Kinetic allows users to set up ACL identities, this is very useful so here
is an example of how to go about creating and issuing a set_acl command
"""
import sys
from argparse import ArgumentParser
from kv_client import Client, kinetic_pb2, common

StatusCodes = kinetic_pb2.Command.Status.StatusCode
MsgTypes = kinetic_pb2.Command.MessageType
Permissions = kinetic_pb2.Command.Security.ACL.Permission

def callback(errors):
    """
    Prints information about response and formats/appends all non-success
    statuses to the errors list
    """
    def wrapper(msg, cmd, value):
        print "\t\treceived msgType: "+str(MsgTypes.Name(cmd.header.messageType))+\
                ", statusCode: "+str(StatusCodes.Name(cmd.status.code))
        if cmd.status.code != kinetic_pb2.Command.Status.SUCCESS:
            errors.append(str(cmd.status).strip().replace("\n", "."))
    return wrapper

def main():
    parser = ArgumentParser()
    parser.add_argument("-i", "--hostname", required=True, help="The ip address or hostname of the drive to test on")
    args = parser.parse_args()

    # Use the kv_client.common.ACL class to create an ACL identity
    # We're relying on default values to create this ACL but check
    # Kinetic proto documentation for more information on the
    # available fields and what they do.
    acl = common.ACL(identity=2, key="newKey")

    # Use the kv_client.common.Scope class to add scope to your identity
    # This ACL will only have permission to issue get_logs and delete
    # keys that start with the phrase "test"
    scope0 = common.Scope(permissions=[Permissions.Value("GETLOG")])
    scope1 = common.Scope(permissions=[Permissions.Value("DELETE")], offset=0, value="test")
    acl.scopes = [scope0, scope1]

    # Be careful when setting ACL identities. This command will wipe out
    # any ACL settings currently configured on the drive and replace them
    # with the ones in your command. Because of that, we're going to make
    # sure to define the demo identity in our command. The demo identity
    # is the only ACL identity that exists on a drive that is new or has
    # just been ISE'd, and is the identity that the client is configured
    # to use by default.
    demo_acl = common.ACL(identity=1)
    scope = common.Scope(permissions=[i for i in Permissions.values() if i >= 0]) # Give full permission
    demo_acl.scopes = [scope]

    print "Create and connect client"
    client = Client(args.hostname, use_ssl=True, port=8443)
    client.connect()
    if not client.is_connected:
        print "\tFailed to connect"
        return 1

    print "Issuing set_acl command"
    errors = []
    client.callback_delegate = callback(errors)
    client.set_acl([acl, demo_acl])
    client.wait_q(0)
    if errors:
        print "\tFailed set_acl command; "+str(errors)
        return 2

    # Switch to using a non-ssl client so a user could look at this in a
    # network capture (wireshark or something) and see the difference.
    client.close()
    print "Close and re-connect non-ssl client"
    client = Client(args.hostname)
    client.connect()
    if not client.is_connected:
        print "\tFailed to connect"
        return 1
    client.callback_delegate = callback(errors)

    print "Use same old demo ACL identity"
    client.get_log(types=[2])
    client.put("testKey", synchronization=1, force=True)
    client.put("Keytest", synchronization=1, force=True)
    client.delete("testKey", synchronization=1, force=True)
    client.wait_q(0)

    print "Use new ACL identity"
    # You can use multiple identities on the same TCP connection
    # This identity should fail some of these commands because of
    # permissions issues
    client.identity = 2
    client.secret = "newKey"
    client.get_log(types=[2]) # success
    client.delete("testKey", synchronization=1, force=True) # success
    client.put("testKey", synchronization=1, force=True) # fail
    client.delete("Keytest", synchronization=1, force=True) # fail
    client.wait_q(0)

    client.close()
    return 0

if __name__=='__main__':
    sys.exit(main())