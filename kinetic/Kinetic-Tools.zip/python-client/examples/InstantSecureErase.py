"""
A useful script to issue instant secure erase to a Kinetic drive
"""
import sys
from argparse import ArgumentParser
from kv_client import Client, kinetic_pb2

def callback(errors):
    """
    Formats and appends all non-success statuses to the errors list
    """
    def wrapper(msg, cmd, value):
        if cmd.status.code != kinetic_pb2.Command.Status.SUCCESS:
            errors.append(str(cmd.status).strip().replace("\n", "."))
    return wrapper

def main():
    parser = ArgumentParser()
    parser.add_argument("-i", "--hostname", required=True, help="The ip address or hostname of the drive to test on")
    parser.add_argument("-p", "--pin", default="", help="The pin to use when issuing ISE command")
    args = parser.parse_args()

    print "Create and connect client"
    client = Client(args.hostname, port=8443, use_ssl=True)
    errors = []
    client.callback_delegate = callback(errors)
    client.connect()
    if not client.is_connected or errors:
        print "\tFailed to connect client"
        if errors:
            print "\t\t"+str(errors)
        return 1

    print "Issuing ISE"
    del errors[:]
    client.instant_secure_erase(args.pin)
    client.wait_q(0)
    client.close()

    if errors:
        print "\tISE failed: "+str(errors)
        return 2
    else:
        print "\tISE successful"
        return 0

if __name__=="__main__":
    sys.exit(main())