"""
Updating firmware on a Kinetic drive takes some special handling because a
successful firmware update will cause the drive to do a soft restart. Here
we have shown how a script can handle that
"""
import os
import sys
import time
import argparse
import subprocess
from kv_client import Client, kinetic_pb2

REACHABILITY_TIMEOUT = 300 # How long to wait for a drive to change state

def ping_device(hostname):
    """
    Issues a single ping to the hostname (redirecting output to NULL)

    Returns
        True: Ping was successful
        False: Ping failed
    """
    with open(os.devnull, 'w') as out:
        results = subprocess.Popen(["ping","-c","1","-W","2", hostname], stdout=out, stderr=out).wait()
        if results is 0:
            return True
        else:
            return False

def wait_for_state_change(hostname, pingable_state):
    """
    Issues pings to the hostname for REACHABILITY_TIMEOUT and
    waits for the ping to return opposite of pingable_state

    Returns
        True: Successfully got a different ping state
        False: Timed out waiting for state change
    """
    t0 = time.time()
    while ping_device(hostname) == pingable_state:
        if time.time()-t0 > REACHABILITY_TIMEOUT:
            return False
    return True

def callback(errors):
    """
    Formats and appends all non-success statuses to the errors list
    """
    def wrapper(msg, cmd, value):
        if cmd.status.code != kinetic_pb2.Command.Status.SUCCESS:
            errors.append(str(cmd.status).strip().replace("\n", "."))
    return wrapper

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--hostname", required=True, help="The ip address or hostname of the drive to test on")
    parser.add_argument("-f", "--firmware", required=True, type=argparse.FileType('rb'), help="The firmware file to give to the drive")
    args = parser.parse_args()

    print "Create and connect client"
    client = Client(args.hostname, port=8443, use_ssl=True)
    errors = []
    client.callback_delegate = callback(errors)
    client.connect()
    if not client.is_connected or errors:
        print "\tFailed to connect client"
        if errors:
            print "\t\t"+str(errors)
        return 1

    print "Issuing firmware update"
    del errors[:]
    client.update_firmware(args.firmware.read())
    client.wait_q(0)
    client.close()
    if errors:
        print "\tFailed update firmware command"
        print "\t\t"+str(errors)
        return 2
    else:
        print "\tSuccessfully issued update firmware"

    print "Waiting for Drive to Go Down"
    if not wait_for_state_change(args.hostname, True):
        print "\tTimed out"
        return 3

    print "Waiting for Drive to Come Back"
    if not wait_for_state_change(args.hostname, False):
        print "\tTimed out"
        return 4

    print "Connecting client"
    print "\tWarning: sometimes linux is up (pingable) but Kinetic isn't yet accepting connections"
    del errors[:]
    client.connect()
    if not client.is_connected:
        print "\tFailed to connect client: "
        print "\t\t"+str(errors)
        return 5
    else:
        print "\tSuccessfully connected to "+str(client.sign_on_msg.body.getLog.configuration.serialNumber)
        print "\t\tReported Firmware Version: "+str(client.sign_on_msg.body.getLog.configuration.version)+\
              " (sourceHash "+str(client.sign_on_msg.body.getLog.configuration.sourceHash)+")"
        client.close()
        return 0

if __name__=="__main__":
    sys.exit(main())